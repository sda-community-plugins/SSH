package com.serena.air.http

import groovy.transform.ToString
import org.apache.http.Header
import org.apache.http.client.methods.CloseableHttpResponse

@ToString
class HttpResponse {
    String body
    int code
    Header[] headers

    HttpResponse(){}
    HttpResponse(CloseableHttpResponse apacheHttpResponse){
        body = apacheHttpResponse.getEntity()?.content?.getText()
        code = apacheHttpResponse.getStatusLine().statusCode
        headers = apacheHttpResponse.getAllHeaders()
    }
}
